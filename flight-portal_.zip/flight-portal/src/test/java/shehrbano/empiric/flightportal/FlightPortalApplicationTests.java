package shehrbano.empiric.flightportal;

import org.junit.Test;
//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
