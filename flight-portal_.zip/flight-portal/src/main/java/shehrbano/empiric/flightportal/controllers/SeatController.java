package shehrbano.empiric.flightportal.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import shehrbano.empiric.flightportal.entities.Flights;
import shehrbano.empiric.flightportal.entities.Seats;
import shehrbano.empiric.flightportal.services.PassengerService;
import shehrbano.empiric.flightportal.entities.Passengers;
import shehrbano.empiric.flightportal.services.SeatService;

import java.util.List;
import java.util.Optional;

@RestController
public class SeatController {

    @Autowired
    private SeatService seatService;

    @RequestMapping("/seats")
    public List<Seats> getAllSeats(){
        return seatService.getAllSeats();
    }

    @RequestMapping("/seats/{id}")
    public Optional<Seats> getSeat(@PathVariable String id){
        return seatService.getSeat(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/seats")
    public void addSeat(@RequestBody Seats seat){
     //   seat.setFlights(new Flights(flightId,"","","","","",""));
        seatService.addSeat(seat);
    }

    @RequestMapping(method=RequestMethod.PUT, value="/seats/{id}")
    public void updateSeat(@RequestBody Seats seat,@PathVariable String id){
      //  seat.setFlights(new Flights(flightId,"","","","","",""));
        seatService.updateSeat(seat);
    }
    @RequestMapping(method=RequestMethod.DELETE, value="/seats/{id}")
    public void deleteSeat(@PathVariable String id){

        seatService.deleteSeat(id);
    }


}