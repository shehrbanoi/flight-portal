package shehrbano.empiric.flightportal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import shehrbano.empiric.flightportal.entities.Aircraft;

import java.util.Optional;

public interface AircraftRepository extends CrudRepository<Aircraft,String>{

}
