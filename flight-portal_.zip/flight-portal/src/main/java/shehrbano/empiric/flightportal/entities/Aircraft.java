package shehrbano.empiric.flightportal.entities;


import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;


@Entity

@Table(name = "Aircraft")
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor

public class Aircraft {


    @Id
//@NotNull
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public String aircraftid;

    @Column(name = "AIRCRAFT_NAME")
    public String aircraftName;
    public String aircraftModel;
    public String seats;
    public String built;
    public String serviced;
    //@ManyToOne
   // private Flights flights;

   // public Flights getFlights() {
       ///// return flights;
//   }

   // public void setFlights(Flights flights) {
    //    this.flights = flights;
   // }

   /* public Aircraft() {
    }*/

  /*  public Aircraft(String aircraftid, String aircraftName, String aircraftModel, String seats, String built, String serviced) {
        super();
        this.aircraftid = aircraftid;
        this.aircraftName = aircraftName;
        this.aircraftModel = aircraftModel;
        this.seats = seats;
        this.built = built;
        this.serviced = serviced;
    }*/


    public String getAircraftid() {
        return aircraftid;
    }

    public void setAircraftid(String aircraftid) {
        this.aircraftid = aircraftid;
    }

    public String getAircraftName() {
        return aircraftName;
    }

    public void setAircraftName(String aircraftName) {
        this.aircraftName = aircraftName;
    }

    public String getAircraftModel() {
        return aircraftModel;
    }

    public void setAircraftModel(String aircraftModel) {
        this.aircraftModel = aircraftModel;
    }

    public String getSeats() {
        return seats;
    }

    public void setSeats(String seats) {
        this.seats = seats;
    }

    public String getBuilt() {
        return built;
    }

    public void setBuilt(String built) {
        this.built = built;
    }

    public String getServiced() {
        return serviced;
    }

    public void setServiced(String serviced) {
        this.serviced = serviced;
    }
}

