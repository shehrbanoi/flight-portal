package shehrbano.empiric.flightportal.repositories;

import org.springframework.data.repository.CrudRepository;
import shehrbano.empiric.flightportal.entities.Seats;

public interface SeatRepository extends CrudRepository<Seats, String> {
}
