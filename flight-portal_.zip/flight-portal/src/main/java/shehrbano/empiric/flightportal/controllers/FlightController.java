package shehrbano.empiric.flightportal.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import shehrbano.empiric.flightportal.entities.Flights;
import shehrbano.empiric.flightportal.services.FlightService;

import java.util.List;
import java.util.Optional;

@RestController
public class FlightController {

    @Autowired
    private FlightService flightService;

    @RequestMapping("/flights")
    public List<Flights> getAllFlights(){
     /**   String filePath = "C:\\Users\\ShehrbanoIbrahim\\Downloads\\flight-portal\\flight-portal\\src\\main\\resources\\data.txt";


        StringBuilder contentBuilder = new StringBuilder();

        try (Stream<String> stream = Files.lines( Paths.get(filePath), StandardCharsets.UTF_8))
        {
            stream.forEach(s -> {
                contentBuilder.append(s);
                contentBuilder.append("\n");
            });
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        String read = contentBuilder.toString();
        new JdbcTemplate().execute(read);
*/
        return flightService.getAllFlights();
    }

    @RequestMapping("/flights/{id}")
    public Optional<Flights> getFlight(@PathVariable String id){

        return flightService.getFlight(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/flights")
    public void addFlight(@RequestBody Flights flight){
        flightService.addFlight(flight);
    }

    @RequestMapping(method=RequestMethod.PUT, value="/flights/{id}")
    public void updateFlight(@RequestBody Flights flights,@PathVariable String id){
        flightService.updateFlight(id,flights);
    }
    @RequestMapping(method=RequestMethod.DELETE, value="/flights/{id}")
    public void deleteFlight(@PathVariable String id){

        flightService.deleteFlight(id);
    }


}
