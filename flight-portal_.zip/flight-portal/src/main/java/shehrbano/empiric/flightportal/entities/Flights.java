package shehrbano.empiric.flightportal.entities;


import javax.persistence.*;

@Table
@Entity
public class Flights {

    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "AIRCRAFT_NAME",nullable = true)
    private Aircraft aircraft;

    @Id
//@NotNull
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;
    private String flightName;
    private String fro;
    private String too;
    private String dep;
    private String arr;
    private String aircraftName;

    public Flights() {
    }

    public Flights(String id, String flightName, String fro, String too, String dep, String arr, String aircraftName) {
        super();
        this.id = id;
        this.flightName = flightName;
        this.fro = fro;
        this.too = too;
        this.dep = dep;
        this.arr = arr;
        this.aircraftName = aircraftName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFlightName() {
        return flightName;
    }

    public void setFlightName(String flightName) {
        this.flightName = flightName;
    }

    public String getFro() {
        return fro;
    }

    public void setFro(String fro) {
        this.fro = fro;
    }

    public String getToo() {
        return too;
    }

    public void setToo(String too) {
        this.too = too;
    }

    public String getDep() {
        return dep;
    }

    public void setDep(String dep) {
        this.dep = dep;
    }

    public String getArr() {
        return arr;
    }

    public void setArr(String arr) {
        this.arr = arr;
    }

    public String getAircraft() {
        return aircraftName;
    }

    public void setAircraft(String aircraft) {
        this.aircraftName = aircraft;
    }
}