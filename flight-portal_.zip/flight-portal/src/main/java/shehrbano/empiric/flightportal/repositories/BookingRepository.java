package shehrbano.empiric.flightportal.repositories;

import org.springframework.data.repository.CrudRepository;
import shehrbano.empiric.flightportal.entities.Bookings;

public interface BookingRepository extends CrudRepository<Bookings, String> {
}
