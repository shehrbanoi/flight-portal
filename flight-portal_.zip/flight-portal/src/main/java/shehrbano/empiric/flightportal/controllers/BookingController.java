package shehrbano.empiric.flightportal.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import shehrbano.empiric.flightportal.entities.Aircraft;
import shehrbano.empiric.flightportal.entities.Bookings;
import shehrbano.empiric.flightportal.entities.Flights;
import shehrbano.empiric.flightportal.services.AircraftService;
import shehrbano.empiric.flightportal.services.BookingService;
import shehrbano.empiric.flightportal.services.PassengerService;
import shehrbano.empiric.flightportal.entities.Passengers;

import java.util.List;
import java.util.Optional;

@RestController
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @RequestMapping("/bookings")
    public List<Bookings> getAllBookings() {
        return bookingService.getAllBookings();
    }

    @RequestMapping("/bookings/{id}")
    public Optional<Bookings> getBooking(@PathVariable String id){
        return bookingService.getBooking(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/bookings")
    public void addBooking(@RequestBody Bookings booking){
       // booking.setFlights(new Flights(flightId,"","","","","",""));
        bookingService.addBooking(booking);
    }

    @RequestMapping(method=RequestMethod.PUT, value="/bookings/{id}")
    public void updateBooking(@RequestBody Bookings booking, @PathVariable String id){
       // booking.setFlights(new Flights(flightId,"","","","","",""));
        bookingService.updateBooking(booking);
    }
    @RequestMapping(method=RequestMethod.DELETE, value="/bookings/{id}")
    public void deleteBooking(@PathVariable String id){
        bookingService.deleteBooking(id);
    }


}
