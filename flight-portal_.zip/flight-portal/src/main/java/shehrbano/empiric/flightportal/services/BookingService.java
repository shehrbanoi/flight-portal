package shehrbano.empiric.flightportal.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import shehrbano.empiric.flightportal.entities.Aircraft;
import shehrbano.empiric.flightportal.entities.Bookings;
import shehrbano.empiric.flightportal.entities.Flights;
import shehrbano.empiric.flightportal.repositories.AircraftRepository;
import shehrbano.empiric.flightportal.repositories.BookingRepository;
import shehrbano.empiric.flightportal.repositories.FlightRepository;

import java.util.*;

@Service
@Component
public class BookingService {

    @Autowired
    BookingRepository bookingRepository;

    public List<Bookings> getAllBookings(){
        List<Bookings> bookings = new ArrayList<>();
        bookings= (List<Bookings>) bookingRepository.findAll();
        return bookings;
    }

    public Optional<Bookings> getBooking(String id){
        return bookingRepository.findById(id);
    }

    public void addBooking(Bookings booking){
        bookingRepository.save(booking);
    }


    public void updateBooking( Bookings booking) {

        bookingRepository.save(booking);
    }

    public void deleteBooking(String id) {

        bookingRepository.deleteById(id);
    }
}
