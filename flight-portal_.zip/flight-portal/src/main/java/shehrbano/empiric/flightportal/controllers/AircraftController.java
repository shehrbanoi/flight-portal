package shehrbano.empiric.flightportal.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import shehrbano.empiric.flightportal.entities.Aircraft;
import shehrbano.empiric.flightportal.entities.Flights;
import shehrbano.empiric.flightportal.services.AircraftService;
import shehrbano.empiric.flightportal.services.PassengerService;
import shehrbano.empiric.flightportal.entities.Passengers;

import java.util.List;
import java.util.Optional;

@RestController
public class AircraftController {

    @Autowired
    private AircraftService aircraftService;

    @RequestMapping("/aircrafts")
    public List<Aircraft> getAllAircrafts(){
        return aircraftService.getAllAircrafts();
    }

    @RequestMapping("/aircrafts/{id}")
    public Optional<Aircraft> getAircraft(@PathVariable String id){
        return aircraftService.getAircraft(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/aircrafts")
    public void addAircraft(@RequestBody Aircraft aircraft){
        //aircraft.setFlights(new Flights(flightId,"","","","","",""));
       aircraftService.addAircraft(aircraft);
    }

    @RequestMapping(method=RequestMethod.PUT, value="/aircrafts/{id}")
    public void updateAircraft(@RequestBody Aircraft aircraft,  @PathVariable String id){
        //aircraft.setFlights(new Flights(flightId,"","","","","",""));
        aircraftService.updateAircraft(aircraft);
    }
    @RequestMapping(method=RequestMethod.DELETE, value="/aircrafts/{id}")
    public void deleteAircraft(@PathVariable String id){
        aircraftService.deleteAircraft(id);
    }


}
