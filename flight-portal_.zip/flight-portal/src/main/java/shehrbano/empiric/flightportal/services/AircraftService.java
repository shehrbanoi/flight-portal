package shehrbano.empiric.flightportal.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import shehrbano.empiric.flightportal.entities.Aircraft;
import shehrbano.empiric.flightportal.entities.Flights;
import shehrbano.empiric.flightportal.repositories.AircraftRepository;
import shehrbano.empiric.flightportal.repositories.FlightRepository;

import java.util.*;

@Service
@Component
public class AircraftService {

    @Autowired
    AircraftRepository aircraftRepository;

    public List<Aircraft> getAllAircrafts(){
        List<Aircraft> aircrafts = new ArrayList<>();
        aircrafts= (List<Aircraft>) aircraftRepository.findAll();
        return aircrafts;
    }

    public Optional<Aircraft> getAircraft(String id){
        return aircraftRepository.findById(id);
    }

    public void addAircraft(Aircraft aircraft){
        aircraftRepository.save(aircraft);
    }


    public void updateAircraft( Aircraft aircraft) {
        aircraftRepository.save(aircraft);
    }

    public void deleteAircraft(String id) {
        aircraftRepository.deleteById(id);
    }
}
