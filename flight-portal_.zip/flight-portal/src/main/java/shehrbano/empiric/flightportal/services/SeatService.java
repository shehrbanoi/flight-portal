package shehrbano.empiric.flightportal.services;

import antlr.ASTNULLType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import shehrbano.empiric.flightportal.entities.Aircraft;
import shehrbano.empiric.flightportal.entities.Seats;
import shehrbano.empiric.flightportal.repositories.SeatRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Component
public class SeatService {

    @Autowired
    SeatRepository seatRepository;

    public List<Seats> getAllSeats(){
        List<Seats> seats = new ArrayList<>();
        seats= (List<Seats>) seatRepository.findAll();
        return seats;
    }

    public Optional<Seats> getSeat(String id){
        return seatRepository.findById(id);
    }

    public void addSeat(Seats seat){
        seatRepository.save(seat);
    }


    public void updateSeat(Seats seat) {
        seatRepository.save(seat);
    }

    public void deleteSeat(String id) {
        seatRepository.deleteById(id);
    }
}
