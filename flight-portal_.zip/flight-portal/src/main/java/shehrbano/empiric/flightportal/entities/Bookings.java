package shehrbano.empiric.flightportal.entities;


import javax.persistence.*;

@Entity
public class Bookings {

    @Id
//@NotNull
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;
    private String flightName;
    private String datim;
    private String passengerName;
    private String rowNo;
    private String seat;
    private String bookingId;
    //@ManyToOne
    //private Flights flights;

   // public Flights getFlights() {
       // return flights;
    //}

    //public void setFlights(Flights flights) {
      //  this.flights = flights;
   // }

        public Bookings() {
    }

    public Bookings(String id, String flightName, String datim, String passengerName, String rowNo, String seat, String bookingId) {
        super();
        this.id = id;
        this.flightName = flightName;
        this.datim = datim;
        this.passengerName=passengerName;
        this.rowNo=rowNo;
        this.seat=seat;
        this.bookingId=bookingId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFlightName() {
        return flightName;
    }

    public void setFlightName(String flightName) {
        this.flightName = flightName;
    }

    public String getDatim() {
        return datim;
    }

    public void setDatim(String datim) {
        this.datim = datim;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getRowNo() {
        return rowNo;
    }

    public void setRowNo(String rowNo) {
        this.rowNo = rowNo;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }
}
