package shehrbano.empiric.flightportal.repositories;

import org.springframework.data.repository.CrudRepository;
import shehrbano.empiric.flightportal.entities.Passengers;

import java.util.List;

public interface PassengerRepository extends CrudRepository<Passengers,String>{

    public List<Passengers> findByFlightsId(String flightId);
    public List<Passengers> findByDesc(String desc);



}
