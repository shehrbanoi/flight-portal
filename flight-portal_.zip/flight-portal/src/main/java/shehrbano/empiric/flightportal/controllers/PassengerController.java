package shehrbano.empiric.flightportal.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import shehrbano.empiric.flightportal.entities.Flights;
import shehrbano.empiric.flightportal.services.PassengerService;
import shehrbano.empiric.flightportal.entities.Passengers;

import java.util.List;
import java.util.Optional;

@RestController
public class PassengerController {

    @Autowired
    private PassengerService passengerService;

    @RequestMapping("/flights/{id}/passengers")
    public List<Passengers> getAllPassengers(@PathVariable String id){
        return passengerService.getAllPassengers(id);
    }

    @RequestMapping("/flights/{flightId}/passengers/{id}")
    public Optional<Passengers> getPassenger(@PathVariable String id, @PathVariable String flightId){
        return passengerService.getPassenger(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/flights/{flightId}/passengers/{id}")
    public void addPassenger(@RequestBody Passengers passenger,@PathVariable String flightId){
        passenger.setFlights(new Flights(flightId,"","","","","",""));
        passengerService.addPassenger(passenger);
    }

    @RequestMapping(method=RequestMethod.PUT, value="/flights/{flightId}/passengers/{id}")
    public void updatePassenger(@RequestBody Passengers passenger, @PathVariable String flightId, @PathVariable String id){
        passenger.setFlights(new Flights(flightId,"","","","","",""));
        passengerService.updatePassenger( passenger);
    }
    @RequestMapping(method=RequestMethod.DELETE, value="/flights/{flightId}/passengers/{id}")
    public void deletePassenger(@PathVariable String id, @PathVariable String flightId){
        passengerService.deletePassenger(id);
    }


}
