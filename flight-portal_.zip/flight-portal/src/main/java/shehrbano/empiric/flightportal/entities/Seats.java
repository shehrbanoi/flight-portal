package shehrbano.empiric.flightportal.entities;


import javax.persistence.*;

@Entity
public class Seats {

    @Id
//@NotNull
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;
    private String aircraftName;
    private String rowNo;
    private String seat;
    private String seatType;
    private String cabinClass;
   // @ManyToOne
    //private Flights flights;

  //  public Flights getFlights() {
    //    return flights;
  //  }

//   public void setFlights(Flights flights) {
        //this.flights = flights;
  //  }


    public Seats() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAircraftName() {
        return aircraftName;
    }

    public void setAircraftName(String aircraftName) {
        this.aircraftName = aircraftName;
    }

    public String getRowNo() {
        return rowNo;
    }

    public void setRowNo(String rowNo) {
        this.rowNo = rowNo;
    }

    public String getSeat() {
        return seat;
    }

    public void setSeat(String seat) {
        this.seat = seat;
    }

    public String getSeatType() {
        return seatType;
    }

    public void setSeatType(String seatType) {
        this.seatType = seatType;
    }

    public String getCabinClass() {
        return cabinClass;
    }

    public void setCabinClass(String cabinClass) {
        this.cabinClass = cabinClass;
    }

    public Seats(String id, String aircraftName, String rowNo, String seat, String seatType, String cabinClass) {
        super();
        this.id = id;
        this.aircraftName=aircraftName;
        this.rowNo=rowNo;
        this.seat=seat;
        this.seatType=seatType;
        this.cabinClass=cabinClass;

    }

}