INSERT INTO FLIGHTS VALUES(707, 'KHI', 'LHR', '0930', '1130', 'A320');


INSERT INTO AIRCRAFT VALUES('A320', 'Airbus', '180', 2009, '06/01/2019');
INSERT INTO AIRCRAFT VALUES ('B747', 'Boeing', 210, 2017, '10/15/2018');

INSERT INTO SEATS (Aircraft,Row,Seat,Type,Class) VALUES
( 'A730', 1, 'A', 'Window', 'First'),
('A730', 2, 'A', 'Window', 'Economy'),
('A730', 1, 'C', 'Aisle', 'Economy'),
('A730', 2, 'C', 'Aisle', 'Business');

INSERT INTO BOOKINGS VALUES('747', '10/01/19', 'Shehrbano', 12, 'A', CNIC123);
INSERT INTO BOOKINGS VALUES (909, '14/01/20', 'Empiric', '5', 'B', CNIC234);
INSERT INTO BOOKINGS VALUES (909, '10/04/21', 'AI', '15', 'C', CNIC321);

