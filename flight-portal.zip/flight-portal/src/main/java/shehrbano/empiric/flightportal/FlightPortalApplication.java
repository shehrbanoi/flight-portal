package shehrbano.empiric.flightportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;


@SpringBootApplication
public class FlightPortalApplication {

	public static void main(String[] args) {



		SpringApplication.run(FlightPortalApplication.class, args);
	}

}
