package shehrbano.empiric.flightportal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import shehrbano.empiric.flightportal.flights.FlightService;
import shehrbano.empiric.flightportal.flights.Flights;

import java.util.Arrays;
import java.util.List;

@RestController
public class AppController {

    @RequestMapping("/hello")
    public String helloWorld() {
        return "Hello World";
    }




}
