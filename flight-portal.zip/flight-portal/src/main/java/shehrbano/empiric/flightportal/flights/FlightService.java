package shehrbano.empiric.flightportal.flights;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class FlightService {

    @Autowired
    FlightRepository flightRepository;

    public List<Flights> getAllFlights(){
        List<Flights> flights = new ArrayList<>();
        flights= (List<Flights>) flightRepository.findAll();
        return flights;
    }

    public Optional<Flights> getFlight(String id){
        return flightRepository.findById(id);
    }

    public void addFlight(Flights flight){
        flightRepository.save(flight);
    }


    public void updateFlight(String id, Flights flight) {
        flightRepository.save(flight);
    }

    public void deleteFlight(String id) {
        flightRepository.deleteById(id);
    }
}
