package shehrbano.empiric.flightportal.passengers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class PassengerService {

    @Autowired
    private PassengerRepository passengerRepository;

    public List<Passengers> getAllPassengers(String flightId){
        List<Passengers> passengers = new ArrayList<>();
        passengerRepository.findByFlightsId(flightId).forEach(passengers::add);
        return passengers;
    }

    public Optional<Passengers> getPassenger(String id){
        return passengerRepository.findById(id);
    }

    public void addPassenger(Passengers passenger){
        passengerRepository.save(passenger);
    }


    public void updatePassenger( Passengers passenger) {
        passengerRepository.save(passenger);
    }

    public void deletePassenger(String id) {
        passengerRepository.deleteById(id);
    }
}
